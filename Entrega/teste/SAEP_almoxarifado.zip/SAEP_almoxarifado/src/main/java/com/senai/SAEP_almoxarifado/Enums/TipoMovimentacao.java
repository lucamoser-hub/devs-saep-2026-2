package com.senai.SAEP_almoxarifado.Enums;


public enum TipoMovimentacao {
    ENTRADA,
    SAIDA
}