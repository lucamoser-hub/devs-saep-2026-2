package com.senai.SAEP_almoxarifado.Repository;


import com.senai.SAEP_almoxarifado.Entity.MovimentacaoEstoque;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MovimentacaoEstoqueRepository extends JpaRepository<MovimentacaoEstoque, Long> {
    List<MovimentacaoEstoque> findAllByOrderByDataMovimentacaoDesc();
}