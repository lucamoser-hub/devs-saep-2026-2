package com.senai.SAEP_almoxarifado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaepAlmoxarifadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaepAlmoxarifadoApplication.class, args);
	}

}
