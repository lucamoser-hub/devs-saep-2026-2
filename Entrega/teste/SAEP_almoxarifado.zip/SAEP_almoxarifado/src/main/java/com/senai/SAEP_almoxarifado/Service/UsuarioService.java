package com.senai.SAEP_almoxarifado.Service;


import com.senai.SAEP_almoxarifado.Entity.Usuario;
import com.senai.SAEP_almoxarifado.Repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    public Optional<Usuario> autenticar(String login, String senha) {
        return usuarioRepository.findByLoginAndSenha(login, senha);
    }
}