package com.senai.SAEP_almoxarifado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaepAlmoxarifadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
